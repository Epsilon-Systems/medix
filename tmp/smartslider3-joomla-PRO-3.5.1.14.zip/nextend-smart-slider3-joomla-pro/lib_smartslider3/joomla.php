<?php
defined('_JEXEC') or die;

define('SMARTSLIDER3_LIBRARY_PATH', dirname(__FILE__) . '/src');

define('N2SSTRY', 0);
define('N2BUILD', 0);

define('N2WORDPRESS', 0);
define('N2JOOMLA', 1);

define('N2GSAP', 1);
define('N2SSPRO', 1);

require_once(SMARTSLIDER3_LIBRARY_PATH . '/Autoloader.php');