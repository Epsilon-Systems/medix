<?php


namespace Nextend\Framework\Localization\Joomla\Pomo;

/**
 * Reads the contents of the file in the beginning.
 */
class POMO_CachedIntFileReader extends POMO_CachedFileReader {

}