<?php


namespace Nextend\SmartSlider3Pro\Generator\Joomla;


use Nextend\SmartSlider3\Generator\AbstractGeneratorLoader;

class GeneratorJoomlaLoader extends AbstractGeneratorLoader {

}