<?php


namespace Nextend\SmartSlider3\Widget\Autoplay;


use Nextend\SmartSlider3\Widget\AbstractWidget;

abstract class AbstractWidgetAutoplay extends AbstractWidget {

    protected $key = 'widget-autoplay-';

}