<?php

// Protect from unauthorized access
defined('_JEXEC') or die();