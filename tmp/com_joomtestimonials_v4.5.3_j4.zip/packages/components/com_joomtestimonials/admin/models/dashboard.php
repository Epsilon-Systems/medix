<?php
/**
 * @copyright	Copyright (c) 2013-2018 JoomBoost (https://www.joomboost.com). All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access.
defined('_JEXEC') or die;

/**
 * Model of dashboard view.
 *
 * @package		Joomla.Administrator
 * @subpakage	JoomBoost.Dashboard
 */
class JoomtestimonialsModelDashboard extends JModelLegacy{

	
}