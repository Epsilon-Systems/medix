DROP TABLE IF EXISTS `#__joomtestimonials`;
