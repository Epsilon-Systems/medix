<?php
/**
 * @package        JoomProject
 * @copyright      2013-2019 JoomBoost, joomboost.com
 * @license        GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>

<a href="https://twitter.com/joomboost?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-show-count="false">Follow @joomboost</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>