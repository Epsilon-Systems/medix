<?php

use Nextend\SmartSlider3\Platform\Joomla\Module\Field\FieldEditSlider;

defined('_JEXEC') or die;

class_alias(FieldEditSlider::class, 'JFormFieldEditSlider');