<?php

namespace Nextend\SmartSlider3\Install\Joomla;

class InstallJoomla {

    public static function install() {

    }
}