<?php

namespace Nextend\SmartSlider3\Generator\Joomla;

use Nextend\SmartSlider3\Generator\AbstractGeneratorLoader;

class GeneratorJoomlaLoader extends AbstractGeneratorLoader {

}