/*
Navicat MySQL Data Transfer

Source Server         : No Boss - Desenv
Source Server Version : 50559

Target Server Type    : MYSQL
Target Server Version : 50559
File Encoding         : 65001

Date: 2018-03-26 11:52:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for #__noboss_testimonial
-- ----------------------------
DROP TABLE IF EXISTS `#__noboss_testimonial`;

/*
Navicat MySQL Data Transfer

Source Server         : No Boss - Desenv
Source Server Version : 50559

Target Server Type    : MYSQL
Target Server Version : 50559
File Encoding         : 65001

Date: 2018-03-26 11:52:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for #__noboss_testimonial_group
-- ----------------------------
DROP TABLE IF EXISTS `#__noboss_testimonial_group`;

/*
Navicat MySQL Data Transfer

Source Server         : No Boss - Desenv
Source Server Version : 50559
Target Server Type    : MYSQL
Target Server Version : 50559
File Encoding         : 65001

Date: 2018-03-26 11:52:55
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for #__noboss_testimonial_photo
-- ----------------------------
DROP TABLE IF EXISTS `#__noboss_testimonial_photo`;
